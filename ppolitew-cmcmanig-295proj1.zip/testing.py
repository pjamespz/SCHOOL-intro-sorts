import sorting 
import random
import time
import pandas as pd
import sys
import math

schooldf =  pd.read_csv("NLSD_DIST.txt")