# DATA260P Project 1: Sorting Algorithms

## Peyton Politewicz and Connor McManigal

- Implemented MergeSort, QuickSort, InsertionSort, ShellSort, BucketSort, RadixSort, BinaryInsertionSort, and QuickSort Median of Medians
- Compared time complexity of each on truly random generated arrays and almost sorted generated arrays at sizes 1000, 2000, 4000, 8000, and 16000
